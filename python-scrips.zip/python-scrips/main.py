import pyodbc

# Connection parameters
server = 'localhost'
database = ''
username = 'SA'
password = 'Thienan@1996'

conn = pyodbc.connect(
    'DRIVER={FreeTDS};'
    f'SERVER={server};'
    f'DATABASE={database};'
    f'UID={username};'
    f'PWD={password};',
    autocommit=True
)

cur = conn.cursor()
result = cur.execute("SELECT 1")
print("Connection successful:", result.scalar() == 1)
